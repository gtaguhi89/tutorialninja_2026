import { test, expect } from '@playwright/test';

test.beforeEach(async({page})=>{
    await page.goto('https://tutorialsninja.com/demo/index.php?route=common/home');
});

test.skip( ({browserName})=> browserName === 'webkit', 'Skipping wibkit on Windows');

test.describe.only('Currency', ()=>{

    test('USD Dollar $', async({page})=>{
        
        // Change Current Currency 
        await page.getByRole('button', { name: '$ Currency  ' }).click();
        await page.getByRole('button', { name: '$US Dollar' }).click();

        const price_usd_label =  page.locator('.caption .price');

        // Check Product for USD
        await expect(price_usd_label.nth(0)).toContainText('$602.00');
        await expect(price_usd_label.nth(0)).toContainText('$500.00');

        await expect(price_usd_label.nth(1)).toContainText('$123.20');
        await expect(price_usd_label.nth(1)).toContainText('$101.00');

        await expect(price_usd_label.nth(2)).toContainText('$110.00');
        await expect(price_usd_label.nth(2)).toContainText('$90.00');

        await expect(price_usd_label.nth(3)).toContainText('$98.00');
        await expect(price_usd_label.nth(3)).toContainText('$80.00');

    });

    test('Euro €', async({page})=>{

    });

    test('Pound Sterling £', async({page})=>{

    });

});
