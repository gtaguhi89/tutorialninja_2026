import { test, expect } from '@playwright/test';

test.beforeEach(async({page})=>{
    await page.goto('https://tutorialsninja.com/demo/index.php?route=common/home');
});

test.skip( ({browserName})=> browserName === 'webkit', 'Skipping wibkit on Windows');

test.describe('CURRECY', ()=>{

    test('EURO €', async({page})=>{

        // Set Current Currency to EUR

        await page.getByRole('button', { name: '$ Currency  ' }).click();
        await page.getByRole('button', { name: '€Euro' }).click();

        // Check the Products in EUR

        await expect(page.locator('.caption .price').nth(0)).toContainText('472.33€');
        await expect(page.locator('.caption .price').nth(0)).toContainText('392.30€');

        await expect(page.locator('.caption .price').nth(1)).toContainText('96.66€');
        await expect(page.locator('.caption .price').nth(1)).toContainText('79.24€');

        await expect(page.locator('.caption .price').nth(2)).toContainText('86.31€');
        await expect(page.locator('.caption .price').nth(2)).toContainText('95.72€');
        await expect(page.locator('.caption .price').nth(2)).toContainText('70.61€');

        await expect(page.locator('.caption .price').nth(3)).toContainText('76.89€');
        await expect(page.locator('.caption .price').nth(3)).toContainText('95.72€');
        await expect(page.locator('.caption .price').nth(3)).toContainText('62.77€');


     
});
    test('POUND STERLING £', async({page})=>{

        // Set Current Currency to POUND STERLING £

        await page.getByRole('button', { name: '$ Currency  ' }).click();
        await page.getByRole('button', { name: '£Pound Sterling' }).click()

        // Check the Products in POUND STERLING £

        await expect(page.locator('.caption .price').nth(0)).toContainText('£368.73');
        await expect(page.locator('.caption .price').nth(0)).toContainText('£306.25');

        await expect(page.locator('.caption .price').nth(1)).toContainText('£75.46');
        await expect(page.locator('.caption .price').nth(1)).toContainText('£61.86');

        await expect(page.locator('.caption .price').nth(2)).toContainText('£67.38');
        await expect(page.locator('.caption .price').nth(2)).toContainText('£74.73');
        await expect(page.locator('.caption .price').nth(2)).toContainText('£55.13');

        await expect(page.locator('.caption .price').nth(3)).toContainText('£60.03 ');
        await expect(page.locator('.caption .price').nth(3)).toContainText('£74.73');
        await expect(page.locator('.caption .price').nth(3)).toContainText('£49.00');

});

});