import {expect, test } from '@playwright/test';

test.beforeEach(async({page})=>{
    await page.goto('https://tutorialsninja.com/demo/index.php?route=common/home');
});

test.skip( ({browserName})=> browserName === 'webkit', 'Skipping WebKit...');

test.describe('Search', ()=>{

    const positiveTerms = ['mac', 'iphone'];

    for(let term of positiveTerms){
         test(`Seatch For ${term}`, async({page})=>{
            await page.getByRole('textbox', { name: 'Search' }).click();
            await page.getByRole('textbox', { name: 'Search' }).fill(term);
            await page.locator('#search').getByRole('button').click();

            const products = await page.locator('.caption h4').allTextContents();
            console.log(products); // [ 'iMac', 'MACBook', 'MacBook Air', 'MacBook Pro'];
            
            for(let elem of products){
                expect(elem.toLowerCase()).toContain(term);
            }
        });
    }


    const negaviteTerms = [];



    
    // test('Seatch For Mac', async({page})=>{
    //     await page.getByRole('textbox', { name: 'Search' }).click();
    //     await page.getByRole('textbox', { name: 'Search' }).fill('Mac');
    //     await page.locator('#search').getByRole('button').click();

    //     const products = await page.locator('.caption h4').allTextContents();
    //     console.log(products); // [ 'iMac', 'MACBook', 'MacBook Air', 'MacBook Pro'];
        
    //     for(let elem of products){
    //         expect(elem.toLowerCase()).toContain('mac');
    //     }
    // });



    // test('Seatch For iPhone', async({page})=>{
    //     await page.getByRole('textbox', { name: 'Search' }).click();
    //     await page.getByRole('textbox', { name: 'Search' }).fill('iphone');
    //     await page.locator('#search').getByRole('button').click();

    //     const products = await page.locator('.caption h4').allTextContents();
    //     console.log(products); // [ 'iMac', 'MACBook', 'MacBook Air', 'MacBook Pro'];
        
    //     for(let elem of products){
    //         expect(elem.toLowerCase()).toContain('iphone');
    //     }
    // });

});


// 