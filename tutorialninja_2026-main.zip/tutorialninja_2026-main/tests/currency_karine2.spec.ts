import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto(
    "https://tutorialsninja.com/demo/index.php?route=common/home",
  );
});

test.describe("Currency dropdown functionality", () => {
  test("should allow the user to change currency from the dropdown", async ({page}) => {

    // Open currency dropdown
    await page.getByRole("button", { name: /currency/i }).click();

    // Verify all currency options are visible
    await expect(page.getByRole("button", { name: "€Euro" })).toBeVisible();
    await expect(page.getByRole("button", { name: "£Pound Sterling" })).toBeVisible();
    await expect(page.getByRole("button", { name: "$US Dollar" })).toBeVisible();

    // Select Euro
    await page.getByRole("button", { name: "€Euro" }).click();
    await expect(page.getByRole("button", { name: /€ currency/i })).toBeVisible();

    // Select Pound Sterling
    await page.getByRole("button", { name: /€ currency/i }).click();
    await page.getByRole("button", { name: "£Pound Sterling" }).click();
    await expect(page.getByRole("button", { name: /£ currency/i })).toBeVisible();

    // Select US Dollar
    await page.getByRole("button", { name: /£ currency/i }).click();
    await page.getByRole("button", { name: "$US Dollar" }).click();
    await expect(page.getByRole("button", { name: /\$ currency/i })).toBeVisible();
  });

  test("should update featured items prices when the currency is changed", async ({page}) => {

    // Options: USD | EUR | GBP
    const selectedCurrency = "EUR"; 

    // Open the currency dropdown
    await page.getByRole("button", { name: /currency/i }).click();

    //-----------------------------------
    // ----------- EUR branch -----------
    //-----------------------------------

    if (selectedCurrency === "EUR") {
      // Select Euro from the dropdown
      await page.getByRole("button", { name: "€Euro" }).click();

      // Verify first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toContainText(/392\.30€/);

      // Verify second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*79\.24\s*€/);

      // Verify third product
      await expect(page.getByText("86.31€")).toBeVisible();
      // Verify sale price of a product
      await expect(page.getByText("95.72€").nth(1)).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(
        page.locator('//*[@id="content"]/div[2]/div[3]/div/div[2]/p[2]'),
      ).toContainText(/Ex Tax:\s*70\.61€/);

      // Verify forth featured product price block is visible
      await expect(page.getByText("76.89€")).toBeVisible();
      await expect(page.getByText("95.72€").nth(1)).toBeVisible();
      // Verify third featured product price block is visible
      await expect(page.locator('//*[@id="content"]/div[2]/div[4]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*62\.77€/);
      
      // Verify the cart button shows currency symbol € correctly
      await expect(page.getByRole("button", { name: /item\(s\).*€/ })).toBeVisible();

      //-----------------------------------
      // ----------- GBP branch -----------
      //-----------------------------------
    } else if (selectedCurrency === "GBP") {
      // Select Pound Sterling from the dropdown
      await page.getByRole("button", { name: "£Pound Sterling" }).click();

      // Verify first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toContainText(/392\.30£/);

      // Verify second product 
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*79\.24£/);

      // Verify third product 
      await expect(page.getByText("86.31£")).toBeVisible();
      // Verify sale price of a product
      await expect(page.getByText("95.72£")).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[3]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*70\.61£/);

      // Verify forth product
      await expect(page.getByText("76.89£")).toBeVisible();
      // Verify sale price of a product
      await expect(page.getByText("95.72£").nth(1)).toBeVisible();
      // Verify third featured product price block is visible
      await expect(page.locator('//*[@id="content"]/div[2]/div[4]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*62\.77£/);
      
      // Verify the cart button shows currency symbol £ correctly
      await expect(page.getByRole("button", { name: /item\(s\).*£/ })).toBeVisible();

      //-----------------------------------
      // ----------- USD branch -----------
      //-----------------------------------

    } else {
      // Select US Dollar
      await page.getByRole("button", { name: "$US Dollar" }).click();

      // Verify first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for first product
      await expect(page.locator('//*[@id="content"]/div[2]/div[1]/div/div[2]/p[2]')).toContainText(/\$392\.30/);

      // Verify second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[2]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*\$79\.24/);

      // Verify third product
      await expect(page.getByText("$86.31")).toBeVisible();
      // Verify sale price of a product
      await expect(page.getByText("$95.72")).toBeVisible();
      // Verify specific prices and tax for second product
      await expect(page.locator('//*[@id="content"]/div[2]/div[3]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*\$70\.61/);

      // Verify forth product
      await expect(page.getByText("$76.89")).toBeVisible();
      // Verify sale price of a product
      await expect(page.getByText("$95.72").nth(1)).toBeVisible();
      // Verify forth featured product price block is visible
      await expect(page.locator('//*[@id="content"]/div[2]/div[4]/div/div[2]/p[2]')).toContainText(/Ex Tax:\s*\$62\.77/);
    
      // Verify the cart button shows currency symbol $ correctly
      await expect(page.getByRole("button", { name: /item\(s\).*\$/ })).toBeVisible();
    }
  });
});
