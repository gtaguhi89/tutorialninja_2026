import { test, expect } from '@playwright/test';

test.beforeEach(async({page})=>{
    await page.goto('https://tutorialsninja.com/demo/index.php?route=common/home');
});

test.skip( ({browserName})=> browserName === 'webkit', 'Skipping wibkit on Windows');


test.describe('CART', ()=>{


    test('Test Add and Remove from cart', async({page})=>{
        
        // ========== ADD PRODUCT SECTION ==========
        // 1 Click
        await page.getByRole('button', { name: ' Add to Cart' }).first().click();

        await expect(page.getByText('Success: You have added')).toContainText('MacBook');
        await expect(page.getByRole('button', { name: ' 1 item(s) - $' })).toBeVisible();

        // 2 Click
        await page.getByRole('button', { name: ' Add to Cart' }).first().click();
        
        await expect(page.getByText('Success: You have added')).toContainText('MacBook');
        await expect(page.getByRole('button', { name: ' 2 item(s) - $' })).toBeVisible();

        // 3 Click
        await page.getByRole('button', { name: ' Add to Cart' }).nth(1).click();

        await expect(page.getByText('Success: You have added')).toContainText('iPhone');
        await expect(page.getByRole('button', { name: ' 3 item(s) - $' })).toBeVisible();


        // ========== REMOVE PRODUCT SECTION ==========

        // Remove 1
        await page.getByRole('button', { name: ' 3 item(s) - $' }).click();
        await page.getByRole('row', { name: 'MacBook MacBook x2 $1,204.00 ' }).getByRole('button').click();

        await expect(page.getByRole('button', { name: ' 1 item(s) - $' })).toBeVisible();

        // Remove 2
        await page.getByRole('button', { name: ' 1 item(s) - $' }).click();
        await page.getByTitle('Remove').first().click();

        await expect(page.getByRole('button', { name: ' 0 item(s) - $' })).toBeVisible();


        // ========== CART IS EPMPTY SECTION ==========
        await page.getByRole('button', { name: ' 0 item(s) - $' }).click();
        await expect(page.getByText('Your shopping cart is empty!')).toBeVisible();

    });

    test('Cart Visibility', async({page})=>{
        // HOMEWORK
    });

});


